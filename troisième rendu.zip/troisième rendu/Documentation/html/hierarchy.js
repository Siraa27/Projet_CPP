var hierarchy =
[
    [ "Les_couches_du_reseau::Couche", "class_les__couches__du__reseau_1_1_couche.html", [
      [ "Les_couches_du_reseau::CoucheCachee", "class_les__couches__du__reseau_1_1_couche_cachee.html", null ],
      [ "Les_couches_du_reseau::CoucheEntrees", "class_les__couches__du__reseau_1_1_couche_entrees.html", null ],
      [ "Les_couches_du_reseau::CoucheSorties", "class_les__couches__du__reseau_1_1_couche_sorties.html", null ]
    ] ],
    [ "CoucheCachée", "class_couche_cach_xC3_xA9e.html", null ],
    [ "Interface_Saisie_des_donnees::Interface", "class_interface___saisie__des__donnees_1_1_interface.html", null ],
    [ "Les_types_de_reseaux::Matrice", "class_les__types__de__reseaux_1_1_matrice.html", null ],
    [ "Les_couches_du_reseau::Neurone", "class_les__couches__du__reseau_1_1_neurone.html", null ],
    [ "Les_types_de_reseaux::Reseau", "class_les__types__de__reseaux_1_1_reseau.html", [
      [ "Les_types_de_reseaux::ReseauForwarded", "class_les__types__de__reseaux_1_1_reseau_forwarded.html", null ],
      [ "Les_types_de_reseaux::ReseauRecurrent", "class_les__types__de__reseaux_1_1_reseau_recurrent.html", null ]
    ] ]
];